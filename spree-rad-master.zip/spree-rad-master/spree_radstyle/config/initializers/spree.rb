Spree.config do |config|
  # Example:
  # Uncomment to stop tracking inventory levels in the application
  config.track_inventory_levels = false
  config.logo = 'store/RAD_Logo_Lockup_White.svg'
  config.admin_interface_logo = 'admin/RAD_Logo_Lockup_White.svg'
end